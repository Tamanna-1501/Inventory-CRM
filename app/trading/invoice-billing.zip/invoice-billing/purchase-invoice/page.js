export default function Page() {
  return <h1>Purchase Invoice Page</h1>;
}

