export default function Page() {
  return <h1>Sale Invoice Page</h1>;
}

