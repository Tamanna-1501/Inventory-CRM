export default function Page() {
  return <h1>Invoice Billing Page</h1>;
}

