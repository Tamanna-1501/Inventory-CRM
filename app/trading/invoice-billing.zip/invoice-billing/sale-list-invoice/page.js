export default function Page() {
  return <h1>Sale List Invoice Page</h1>;
}

