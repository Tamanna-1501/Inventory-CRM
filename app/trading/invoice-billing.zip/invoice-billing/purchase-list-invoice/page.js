export default function Page() {
  return <h1>Purchase List Invoice Page</h1>;
}

