export default function Page() {
  return <h1>Expense Invoice Page</h1>;
}

