export default function Page() {
  return <h1>Expense List Invoice Page</h1>;
}

